from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import mysql.connector

app = Flask(__name__)
app.secret_key = "secretkey"

@app.route("/")
def home():
    return render_template("index.html")

# Database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="abarna",
    database="credit_system"
)
cursor = db.cursor()
print("Database Connected")

# Signup Route
@app.route('/signup', methods=["GET", "POST"])
def signup():
    if request.method == "GET":
        return render_template("signup.html")

    elif request.method == "POST":
        data = request.json
        name = data['name']
        email = data['email']

        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        existing_user = cursor.fetchone()

        if existing_user:
            return jsonify({"error": "Email already exists", "redirect": url_for('login')}), 400

        cursor.execute("INSERT INTO users (name, email) VALUES (%s, %s)", (name, email))
        user_id = cursor.lastrowid
        cursor.execute("INSERT INTO user_credits (user_id, balance) VALUES (%s, 0)", (user_id,))
        db.commit()

        session['user_id'] = user_id
        return jsonify({"message": "User registered", "redirect": url_for('purchase')}), 201

# Login Route
@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    elif request.method == "POST":
        data = request.json
        email = data['email']

        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()

        if user:
            session['user_id'] = user[0]
            return jsonify({"message": "Login successful", "redirect": url_for('purchase')}), 200
        else:
            return jsonify({"error": "Email not registered", "redirect": url_for('signup')}), 400
        
# Purchase Route
@app.route('/purchase', methods=["GET", "POST"])
def purchase():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login')) 

    if request.method == "GET":
        return render_template("purchase.html")

    elif request.method == "POST":
        cursor.execute("UPDATE user_credits SET balance = balance + 100 WHERE user_id = %s", (user_id,))
        db.commit()
        return jsonify({"redirect": url_for('deduct')}), 200  

@app.route('/deduct', methods=["GET", "POST"])
def deduct():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    cursor.execute("SELECT balance FROM user_credits WHERE user_id = %s", (user_id,))
    balance = cursor.fetchone()[0]

    return render_template("deduct.html", balance=balance)

@app.route('/use_credits', methods=["POST"])
def use_credits():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"error": "User not logged in"}), 401

    cursor.execute("SELECT balance FROM user_credits WHERE user_id = %s", (user_id,))
    balance = cursor.fetchone()[0]

    if balance >= 50:
        cursor.execute("UPDATE user_credits SET balance = balance - 50 WHERE user_id = %s", (user_id,))
        db.commit()
        return jsonify({"message": "50 Credits used successfully", "redirect": url_for('deduct')}), 200
    else:
        return jsonify({"error": "Insufficient balance"}), 400

if __name__ == '__main__':
    app.run(debug=True)